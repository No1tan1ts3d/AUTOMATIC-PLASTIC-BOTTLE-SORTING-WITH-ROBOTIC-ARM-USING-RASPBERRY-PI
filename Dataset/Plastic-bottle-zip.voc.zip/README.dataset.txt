# All plastic bottle > 2024-07-05 8:12am
https://universe.roboflow.com/hero-mb2zf/all-plastic-bottle

Provided by a Roboflow user
License: CC BY 4.0

